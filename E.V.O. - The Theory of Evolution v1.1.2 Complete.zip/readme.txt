﻿                           -------------------------------
                                 46 OkuMen Present
                           E.V.O.: The Theory of Evolution
                                      v1.1.2
                           -------------------------------

                                              `-+o+yyyss:-`                      
                                            `oyoyh/-+++syo/.                    
                                           .oysds/-://:s++h/                    
                                           -//-+:--++h:///dh                    
                                           `+++.//.``:--/hdy.                   
                                            .-:sdo.`-/--+syyy`                  
.............:``-```                         .--ysoo//-/yoyyms:/:://--.         
`:+++hhs+++y++/h::---                        `--mhoo//:dd/ssdmho/++.`-.         
      -yddMdyNy:.++-/`                        `/+/--+o+dd+/+oshmmmmh+.          
      ``+hhdd/..oNy-+.                   -  ---+Ndooys+ds+/-//-/////////        
      .-omydooomhhy-++o`            ``....+osso://y+++/y+soodhyyo---//-++-      
      --oyNNMhhh//--///+//      ..  ::``:.///ooydddNs//-ys//.`..----//..//:     
     -.://ooy+//-:////--//++`-:`..--//--`---:..```..+N+-:`--//--//--+/-.//:     
       ....      `:s++--//--:-.-//--///ho`--//----..`:sso+--//--//-yh/.`//:     
                    //s///--//--//-/oosyhh``//--//--:.+dyy--//--//-ds+.`///.    
                      --++--//-++++s/.-sdNo`//--//--//:dyy--//--//-ddds..//+    
                          `////`      .ssyd.`/--//--//-dyy--//--//sdyss-`:-/:   
                                       +osd/`:--//--//+dym--//--//o:yos--.-/+.  
                                       +oodm//--//--//dhsmy/////os: .ss-/..-/-  
                                       +oo+oho++++++mm+s+ydmhsyy+-   ./://``-/: 
                                        os--//hhMmhh//-/++yhdmmm-     `///.-.//.
                                        `+o://:yd+--//:y///ymoss      .+//``///.
                                         :-+oom+//:/+oo:ss+smys.       -//.`//+.
                                         /--//mo++o/+/--/++/mss.       .//.`///`
                                        `:ooody-//--//--//-+mss:        -/.`//- 
                                       `:.--/h--//--//--//-+o+/s-       `/.`++. 
                                      .-`.-.//--//o://--//+-//-so:       ---//  
                                     -.``:``//--/sm://-+oo+-//-/oo:      ---//: 
                                    .``.:`--//:mmss+//+/oo--:`--///`    //o:///.
                                   `.`--.---//dmoo/ymmhhoo--/-`.//++   `/syds//+
                                  ..`:``//--+ds+//odysyys++-//``//-+    +o/-//+.
                                 -.``/.-//--yh/+//.:-./+hm+-//.`//-+-    `-`..  
                                 :``-:--//--do+/+/    `:+hmo//-.`/-/:           
                                -...`:--//--//+/:      .++oo//-.`/-/:           
                               `:`..//--//--///+         -++/-.../-+/-          
                              `-.-.-//--//--++o`          `./``.//--//          
                              ...`--//--//-+/:             `/`.-//--++-         
                             --.:---//--//-+.              `/`.-//--++-         
                             :-.//--//--//+                `/.`.//--//:         
                             `--//--//--//+                 //`../--//:         


------------------------
Table of Contents
------------------------
1.0 Basic Information
	1.1 Version History
	1.2 Patch
		1.2.1 Windows
		1.2.2 Mac/Linux/Other
	1.3 License
2.0 Project
	2.1 Playing the Game
	2.2 About the Game
	2.3 About the Project
	2.4 About the Team
3.0 Credits
4.0 Special Thanks
5.0 License
6.0 Contact
------------------------

------------------------
1.0 Basic Information
------------------------

1.1 Version History
------------------------
v1.1.2 - Dec 12, 2017 - Pachy98 update (v0.19.1). Still no changes to content.
v1.1.1 - Jul 06, 2017 - Patcher updated to Pachy98. No changes to content.
v1.1.0 - Apr 03, 2017 - New custom patcher. Grammar, consistency, and formatting fixes.
v1.0.1 - Jan 01, 2017 - Bugfixes
v1.0.0 - Dec 28, 2016 - Initial public release.

1.1 Patch
------------------------

1.1.1 Windows
------------------
	Pachy98 is 46 OkuMen's flexible patcher, new to E.V.O. in v1.1.1.

	Place your E.V.O. disk image files, or the game's files themselves, in the same directory as Pachy98.exe.

	Run Pachy98.exe and it will automatically locate your disk images. Confirm it has found the correct files, and it will back them up to the "/backup" directory and then apply the patches to the images in the root Pachy98 directory. 

	Once completed, you will be able to play the game in English using the disk files you placed in the root directory.
	
1.1.2 Mac/Linux/Other
------------------
	Pachy98 is Windows-only, so if you're using another OS, you can use the provided xdelta patches in the "Mac+Linux Patches" folder. Use a utility like Delta Patcher to patch your copy of the game ( http://www.romhacking.net/utilities/704/ ). Note that this method is a lot less flexible, and only supports a few particular builds of the game.

	If you're patching the floppy disk images you will need to patch each individual disk with the respective patch. There is, however, no patch necessary for the system disk, B 1, which is not used in normal gameplay.

------------------------
2.0 Game
------------------------

2.1 Playing the Game
------------------------
	If this is your first time emulating or playing a PC-98 game, we've written a short setup guide on our site: http://46okumen.com/pc-98-emulation/

	Downloading a system font is highly recommended to make everything display correctly!!! That can be found on the link above as well.

	Once you've patched the disk images, put the user disk in your first floppy disk drive, then disk 2 in your second floppy disk drive. If you're using the hard disk image, simply put the hard disk image in IDE #0. Next, you simply start up (or restart) your system and the game will autoboot. This process applies to both hardware and emulators.

	Also be sure to read the fully translated manual, too. You might find some useful information inside! If the manual wasn't included with this download, you can find it on the E.V.O.: The Theory of Evolution project page on our website: http://46okumen.com/projects/e-v-o-the-theory-of-evolution/

2.2 About the Game
------------------------
	E.V.O.: Search for Eden was released on the SNES system in North America on July 15th, 1993. This was many people in the Western world's first introduction to the series and it became a sort of cult hit. The concept of evolution in a game wasn't exactly utilized in many games at the time so it was pretty novel, even if the actual gameplay and level design was somewhat lacking. Little did most people know, this wasn't the first game in the E.V.O. series, (or that it was even a series at all).

	E.V.O.: The Theory of Evolution (46 Okunen Monogatari: THE Shinkaron) was released in 1990 exclusively for the NEC PC-9800 series of computers, and exclusively in Japanese. Unlike Search for Eden, The Theory of Evolution focused on RPG game mechanics, similar to other Enix RPGs of the time such as the Dragon Quest series, and was much more story-driven than its spiritual successor on the SNES. The world was written and created by Kawamata Chiaki, a well-known science fiction author in Japan at the time, who paid plenty of attention to the backstory and mythos of the game's world. There is a lot of richness and attention to detail to be found here, even if some of it seems to be a little bit on the amusing side instead of being completely serious all the time.

	Be prepared to evolve and play over a span of 4.6 billion years and create your own myths and legends.

2.3 About the Project
------------------------
	The 46 OkuMen team, creators of this patch, are a brand new romhacking and translation team. Two of the three core members have never worked on a romhack before, that's how new. So the fact that this patch exists is a small miracle to most, I'm sure. That being said, this has been in the works for a little over a year, and we had to get through a number of hurdles in that time to get this game out to you guys.

	On the translation side, kuoushi had to figure out things like proper romanizations for every single creature that shows up in the game. That may seem like an easy job, and it kind of is, but it was super tedious having to sift through old Japanese romanizations of ancient animal names that aren't in use anymore. Some of them he had to just read the Japanese and then look through lists of names in English and find the exact name they were talking about just based on the pronunciation. There were also a ton of references to things that were happening in the world of paleontology at the time, as well as things that were happening in Japan at the time. One in particular that ended up being a sort of last piece to the puzzle was the made up Teilhardorphus, which is a reference to the French philosopher and paleontologist Pierre Teilhard de Chardin. The current Japanese romanization of his name is very different from the one used in the game, so trying to figure out just what exactly they were referencing took a bit.

	On the romhacking side, hollowaytape had to learn the entire process from scratch. Much of the beginning of the project was spent figuring out simple things like text encoding and pointers. There were fairly standard pointer tables above text blocks, but most of the game's pointers are hidden in code segments, so finding those took a while. The game's script is also fairly long, so accommodating it removing all the error messages from the game and re-appropriating their space. But the greatest struggle was Almanic's proprietary .GDT image format, which we needed to know in order to insert the translated title screen and chapter title images. The format is fairly intricate, with different flags allowing planes to be encoded with run length, various checkerboard patterns, variations of previous planes, and a few encodings we never figured out. M_bot figured out a lot of the format and wrote a good GDT -> BMP decoder, and hollowaytape wrote an okay BMP -> GDT encoder to get the translated images into the game. Despite all this, the game ended up being a pretty great first ROM to hack - no compression, no font hacking, no copy protection, and no assembly hacks needed.

	All in all, it's been a long road and we're all happy to get this release out the door and in front of you guys to enjoy this game.

2.4 About the Core Team
------------------------
	hollowaytape is a new software developer who works in scientific computing. He started the project while in college. He grew up playing fan-translated games like Seiken Densetsu 3, La-Mulana, and Mother 3, and is excited to finally have the skills and free time to give something back to the community.

	kuoushi is a professional Japanese translator who just so happens to also translate as a hobby. He has worked on a lot of translations over the past 10+ years in many different fields, such as short stories, manga, mobile games, and more. E.V.O.: The Theory of Evolution is the first full romhacking translation project he has ever undertaken, and he's happy to have been a part of it.

	SkyeWelse is a web developer / graphic artist and a hardcore retro-gaming enthusiast / collector. Some of his past websites include miraigamer.net, gameflaws.com, suikocastle.com, cavestory.org, shantae.net, usamsx.com, and more recently retro-type.com, which is planned to become a gaming community at some point in the near future. As a visual person, he really enjoys turning graphics with Japanese texts into English versions.

	Another small but fun fact about the team: we all met because of E.V.O.: The Theory of Evolution. Not one of us knew any of the others before this project started, we all met through the RHDN forums in an old thread from KingMike ( http://www.romhacking.net/forum/index.php/topic,5870.0.html ) with each of us posting shot-in-the-dark posts offering to do some particular part of the project. Can't say that those sorts of posts work out too often, so this is certainly a special project.

	You can find more about the team and our future projects at our website: http://46okumen.com

------------------------
3.0 Credits
------------------------
hollowaytape - Hacking
kuoushi - Translation, Editing, Trailer
SkyeWelse - Title Graphics, Promo Art, Manual Layout
Racoon Sam / SkyeWelse - Main Title Graphic
M-bot - Graphics Hacking
sonofashark / Ultimate - Manual Scans
not_log - Manual Scanlation
joseji, cuba200611 - Special Thanks
Highwang, SkyeWelse, Arboreal, RadGalaxy, measuredincm, gonameyourself - Beta Testing

------------------------
4.0 Special Thanks
------------------------
	We'd like to thank anyone who helped us on this project and whom we may have forgotten to include in the above credits. Members of the Heroes of Legend community were quite helpful when we found ourselves somewhat stuck, such as in locating the dialogue pointers and documenting the .GDT image format. Thanks to the Romhacking.net community for showing some love and support for the game and cheering us along as we progressed through the work on the game. And thanks to the users of the PC-9800 Series Central Discord server for their support, enthusiasm, and tolerance during the final stages of the project.

	Thanks to EsperKnight for developing his tool SJIS Dump.

	Thanks to euee, developer of the NDC utility, the foundation of our custom patching program. You can find him here: http://euee.web.fc2.com/

	kuoushi would like to thank his wife for putting up with him translating old Japanese video games at odd hours.

------------------------
5.0 License
------------------------

	This translation patch is covered by the Creative Commons Attribution-NonCommercial license. A human readable version of the license (as well as the full text of the license) may be found here: https://creativecommons.org/licenses/by-nc/4.0/

	You are free to share and redistribute this patch in any format. You are free to adapt or build upon this patch in any way. However, you must give appropriate credit to us, indicate any changes you've made, and you may not use it for any commercial purposes.

	The patcher program Pachy98.exe is covered by the Apache Public License (version 2). This license can be found here: http://www.apache.org/licenses/LICENSE-2.0

------------------------
6.0 Contact
------------------------
	If you need to get in touch with us for any reason, you can send an e-mail to hollowaytape AT retro-type DOT com or swing by our website at http://46okumen.com
